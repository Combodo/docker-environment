const optionsDTO = {
    php_version: '82',
    url_filter: 'localhost:88',
    enabled: 'true',
    php_version_installed: '{74: "7.4",80: "8.0",81: "8.1",82: "8.2",83: "8.3",84: "8.4"}'
};